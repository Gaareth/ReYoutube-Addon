# ReYoutube-Addon

Browser extension which adds comments to youtube videos that have disabled commenting.

---

The Addon connects to the backend at [reyoutube!](reyoutube.herokuapp.com)

## TODO

- Edit, Delete comments
- Show More/Less Option
